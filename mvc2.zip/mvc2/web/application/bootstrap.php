<?
require_once "config/config.php";
require_once "core/db.php";
$db = new Db();

// подключаем файлы ядра
require_once 'core/model.php';
require_once 'core/view.php';
require_once 'core/controller.php';
require_once 'lib/lib.php';
require_once 'core/route.php';

session_start();

// Добавить пустую корзину при первом входе
$_COOKIE["basket"] = isset($_COOKIE["basket"]) ? $_COOKIE["basket"] : serialize([]); // php7
if(count(unserialize($_COOKIE["basket"])) == 0){
    $uBasket = [];
    $sBasket = serialize($uBasket);
    setcookie("basket", $sBasket, time()+99999999, "/");
}

Route::start($db); // запускаем маршрутизатор
?>