<?
	if ($data === true) {?>
	<div class="alert alert-success">
	  <strong>Товар успешно добавлен!</strong>
	</div> 
<?	}?>

<form method="POST" action="/admin/product/add">
	<input type="text" name="productName" /><br>
	<input type="number" name="productPrice"><br>
	<input type="submit" name="productAdd" value="Добавить">
</form>