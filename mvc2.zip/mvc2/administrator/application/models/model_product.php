<?
class Model_Product extends Model
{
	protected $query;
	public function productAdd(){
		$name = Lib::clearRequest($_POST["productName"]);
		$price = Lib::clearRequest($_POST["productPrice"]);
		$this->query = "INSERT INTO `test`
								(`name`, `price`) 
						VALUES ('$name',$price);";
		return $this->db->makeQuery($this->query);

	}

}