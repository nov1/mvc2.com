<?
//1. отображение ошибок на время разработки сайта
ini_set('display_errors', 1);

$uri = parse_url($_SERVER['REQUEST_URI']);
$admin_uri = explode("/", $uri["path"])[1];
// var_dump($admin_uri);

if ($admin_uri === "admin") {
	require_once 'administrator/application/bootstrap.php'; 
}else{
	require_once 'web/application/bootstrap.php'; 
}
// Front controller

?>