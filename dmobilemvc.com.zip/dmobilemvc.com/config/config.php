<?
const DB_NAME = "HawkEyes";
const DB_HOST = "localhost";
const DB_PASSWD = "v52oks7";
const DB_USER = "HawkEyes";
?>