<div class="container-main">
    <img src="images/back-main.jpg"  width=100% alt="main-img">
</div>
