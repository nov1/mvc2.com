<div class="container-main">
    <img src="images/delivery.png" width=100% >
</div>
