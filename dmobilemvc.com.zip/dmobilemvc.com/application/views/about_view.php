<div class="container-main">
    <img src="images/iphone7-2016.jpg" width=100% >
</div>
<?//var_dump($_SERVER['REQUEST_URI']);?>
